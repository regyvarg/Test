﻿'use strict';
(function () { 
    var userDataApp = angular.module('userDataApp');
    userDataApp.controller('UserDataController', ['$scope', '$rootScope','$state', function ($scope, $rootScope,$state) {
        $rootScope.userData = $rootScope.userData || [];
        $scope.userRecord = {};
        $scope.master = {};
        $scope.submitForm = function (isValid,userRecord) {
            if (isValid) {
                $rootScope.userData.push($scope.userRecord);
                console.log($rootScope.userData);
                $state.go('userdatalist');
            }
        };
        $scope.Reset = function (form) {
            $scope.userRecord = {};
            $scope.userRecord.gpa = '';
            $scope.userRecord.dob = '';
            form.$setPristine();
            form.$setUntouched();
        };
}]);
})();