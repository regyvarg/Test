﻿'use strict';
(function ()
{
    var userDataApp = angular.module('userDataApp', ['ui.router']);
    userDataApp.config(function ($stateProvider, $urlRouterProvider) {
        $urlRouterProvider.otherwise('/userdatainput');
        $stateProvider            
            .state('userdatainput', {
                url: '/userdatainput',
                templateUrl: 'UserDataInput.html',
                controller: 'UserDataController'
            })
            .state('userdatalist', {
                url: '/userdatalist',
                templateUrl: 'UserDataList.html',
                controller: 'UserDataController'
            });
    });
})();